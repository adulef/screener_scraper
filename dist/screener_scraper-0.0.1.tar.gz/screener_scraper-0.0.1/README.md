# screener_scraper
This package can be used an unofficial API for screener.in

## Install


## Usage
These are few use cases of the liberary:
### Case 1
